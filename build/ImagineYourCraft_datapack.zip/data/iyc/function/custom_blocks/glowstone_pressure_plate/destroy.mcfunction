
#> iyc:custom_blocks/glowstone_pressure_plate/destroy
#
# @executed	at @s
#
# @within	iyc:custom_blocks/no_block_below
#			iyc:custom_blocks/_groups/minecraft_stone_pressure_plate
#

function iyc:glow/clear

execute unless entity @n[type=item,nbt={Item:{id:"minecraft:stone_pressure_plate"}},distance=..1] if entity @p[distance=..8,gamemode=survival] run loot spawn ~ ~ ~ loot iyc:i/glowstone_pressure_plate

# Replace the item with the custom one
execute as @n[type=item,nbt={Item:{id:"minecraft:stone_pressure_plate"}},distance=..1] run function iyc:custom_blocks/glowstone_pressure_plate/replace_item

# Decrease count scores
scoreboard players remove #total_custom_blocks iyc.data 1
scoreboard players remove #total_vanilla_stone_pressure_plate iyc.data 1
scoreboard players remove #total_glowstone_pressure_plate iyc.data 1

# Kill the custom block entity
kill @s

# Decrease the number of entities with second tag
scoreboard players remove #second_entities iyc.data 1

