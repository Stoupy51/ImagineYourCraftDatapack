
#> iyc:custom_blocks/raw_steel_block/destroy
#
# @executed	at @s
#
# @within	iyc:custom_blocks/no_block_below
#			iyc:custom_blocks/_groups/minecraft_raw_iron_block
#

# Replace the item with the custom one
execute as @n[type=item,nbt={Item:{id:"minecraft:raw_iron_block"}},distance=..1] run function iyc:custom_blocks/raw_steel_block/replace_item

# Decrease count scores
scoreboard players remove #total_custom_blocks iyc.data 1
scoreboard players remove #total_vanilla_raw_iron_block iyc.data 1
scoreboard players remove #total_raw_steel_block iyc.data 1

# Kill the custom block entity
kill @s

