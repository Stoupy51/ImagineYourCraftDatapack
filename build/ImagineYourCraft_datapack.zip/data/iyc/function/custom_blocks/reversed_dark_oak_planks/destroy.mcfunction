
#> iyc:custom_blocks/reversed_dark_oak_planks/destroy
#
# @executed	at @s
#
# @within	iyc:custom_blocks/no_block_below
#			iyc:custom_blocks/_groups/minecraft_dark_oak_planks
#

# Replace the item with the custom one
execute as @n[type=item,nbt={Item:{id:"minecraft:dark_oak_planks"}},distance=..1] run function iyc:custom_blocks/reversed_dark_oak_planks/replace_item

# Decrease count scores
scoreboard players remove #total_custom_blocks iyc.data 1
scoreboard players remove #total_vanilla_dark_oak_planks iyc.data 1
scoreboard players remove #total_reversed_dark_oak_planks iyc.data 1

# Kill the custom block entity
kill @s

