
#> iyc:custom_blocks/slate_block/destroy
#
# @executed	at @s
#
# @within	iyc:custom_blocks/no_block_below
#			iyc:custom_blocks/_groups/minecraft_coal_block
#

# Replace the item with the custom one
execute as @n[type=item,nbt={Item:{id:"minecraft:coal_block"}},distance=..1] run function iyc:custom_blocks/slate_block/replace_item

# Decrease count scores
scoreboard players remove #total_custom_blocks iyc.data 1
scoreboard players remove #total_vanilla_coal_block iyc.data 1
scoreboard players remove #total_slate_block iyc.data 1

# Kill the custom block entity
kill @s

