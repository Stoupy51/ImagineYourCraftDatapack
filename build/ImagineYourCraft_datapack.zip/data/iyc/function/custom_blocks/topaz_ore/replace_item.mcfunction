
#> iyc:custom_blocks/topaz_ore/replace_item
#
# @executed	as @n[type=item,nbt={Item:{id:"minecraft:polished_deepslate"}},distance=..1]
#
# @within	iyc:custom_blocks/topaz_ore/destroy [ as @n[type=item,nbt={Item:{id:"minecraft:polished_deepslate"}},distance=..1] ]
#

# Mined with a tool too weak
execute if entity @p[distance=..8,gamemode=!creative,gamemode=!spectator] unless items entity @p[distance=..8,gamemode=!creative,gamemode=!spectator] weapon.mainhand #iyc:mining/pickaxe_iron run return run kill @s

# If silk touch applied
execute if score #is_silk_touch iyc.data matches 1 run data modify entity @s Item.id set from storage iyc:items all.topaz_ore.id
execute if score #is_silk_touch iyc.data matches 1 run data modify entity @s Item.components set from storage iyc:items all.topaz_ore.components

# Else, no silk touch
execute if score #is_silk_touch iyc.data matches 0 run data modify entity @s Item.id set from storage iyc:items all.topaz.id
execute if score #is_silk_touch iyc.data matches 0 run data modify entity @s Item.components set from storage iyc:items all.topaz.components
execute if score #is_silk_touch iyc.data matches 0 summon minecraft:experience_orb store result entity @s Value short 1 run random value 3..6

# Get item count in every case
execute store result entity @s Item.count byte 1 run scoreboard players get #item_count iyc.data

