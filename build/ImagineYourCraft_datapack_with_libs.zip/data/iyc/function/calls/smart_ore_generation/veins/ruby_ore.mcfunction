
#> iyc:calls/smart_ore_generation/veins/ruby_ore
#
# @within	iyc:calls/smart_ore_generation/generate_ores
#

# Try to find a random position adjacent to air in the region to generate the ore
function #smart_ore_generation:v1/slots/random_position

# Placing Ruby Ore patch
execute at @s if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~-0.4 ~-0.4 ~-0.4 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~-0.4 ~-0.4 ~0.0 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~-0.4 ~-0.4 ~0.4 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~-0.4 ~0.0 ~-0.4 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~-0.4 ~0.0 ~0.0 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~-0.4 ~0.0 ~0.4 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~-0.4 ~0.4 ~-0.4 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~-0.4 ~0.4 ~0.0 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~-0.4 ~0.4 ~0.4 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~0.0 ~-0.4 ~-0.4 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~0.0 ~-0.4 ~0.0 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~0.0 ~-0.4 ~0.4 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~0.0 ~0.0 ~-0.4 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~0.0 ~0.0 ~0.0 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~0.0 ~0.0 ~0.4 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~0.0 ~0.4 ~-0.4 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~0.0 ~0.4 ~0.0 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~0.0 ~0.4 ~0.4 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~0.4 ~-0.4 ~-0.4 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~0.4 ~-0.4 ~0.0 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~0.4 ~-0.4 ~0.4 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~0.4 ~0.0 ~-0.4 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~0.4 ~0.0 ~0.0 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~0.4 ~0.0 ~0.4 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~0.4 ~0.4 ~-0.4 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~0.4 ~0.4 ~0.0 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main
execute at @s positioned ~0.4 ~0.4 ~0.4 if block ~ ~ ~ #iyc:smart_ore_generation/ruby_ore_provider unless block ~ ~ ~ minecraft:deepslate run function iyc:custom_blocks/ruby_ore/place_main

