
#> iyc:custom_blocks/cherry_cake/replace_item
#
# @executed	as @n[type=item,nbt={Item:{id:"minecraft:cake"}},distance=..1]
#
# @within	iyc:custom_blocks/cherry_cake/destroy [ as @n[type=item,nbt={Item:{id:"minecraft:cake"}},distance=..1] ]
#

# Replace the item with the custom one
data modify entity @s Item.components set from storage iyc:items all.cherry_cake.components
data modify entity @s Item.id set from storage iyc:items all.cherry_cake.id

