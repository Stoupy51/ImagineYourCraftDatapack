
#> iyc:custom_blocks/cobblestone_high_stool/replace_item
#
# @executed	as @n[type=item,nbt={Item:{id:"minecraft:barrier"}},distance=..1]
#
# @within	iyc:custom_blocks/cobblestone_high_stool/destroy [ as @n[type=item,nbt={Item:{id:"minecraft:barrier"}},distance=..1] ]
#

# Replace the item with the custom one
data modify entity @s Item.components set from storage iyc:items all.cobblestone_high_stool.components
data modify entity @s Item.id set from storage iyc:items all.cobblestone_high_stool.id

